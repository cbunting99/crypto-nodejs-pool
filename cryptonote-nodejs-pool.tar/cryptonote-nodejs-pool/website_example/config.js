var api = "https://multi-miner.smartcoinpool.net:8119";
let parentCoin = "Arqma"

var email = "support@poolhost.com";
var telegram = "https://t.me/YourPool";
var discord = "https://discordapp.com/invite/YourPool";
var facebook = "https://www.facebook.com/<YourPoolFacebook>";

var marketCurrencies = ["{symbol}-BTC", "{symbol}-LTC", "{symbol}-DOGE", "{symbol}-USDT", "{symbol}-USD", "{symbol}-EUR", "{symbol}-CAD"];

var blockchainExplorer = "http://chainradar.com/{symbol}/block/{id}";
var blockchainExplorerMerged = "http://explorer.ird.cash/?hash={id}#block";
var transactionExplorer = "http://chainradar.com/{symbol}/transaction/{id}";
var transactionExplorerMerged = "http://explorer.ird.cash/?hash={id}#transaction";

var themeCss = "themes/default.css";
var defaultLang = 'en';
